/*
Exec Login_Details_Insert 'Murali','123','Gandhipet','3216541262'
*/
Create Proc Login_Details_Insert
@userid Varchar(50),
@password Varchar(50),
@address Varchar(max),
@mobilno Varchar(10),
@log_id Varchar(50)
as
Begin

	if Not exists(Select 'X' from User_Details where Mobile_No=@mobilno)
	Begin
		INsert into User_Details (User_Name,Password,Address,Mobile_No,Created_By,Created_On) values(@userid,@password,@address,@mobilno,@log_id,Getdate())
			Select * from User_Details where USER_NAME=@userid
	End
	Else
	Begin
		Raiserror('Already Available for this Mobile No...!!',16,1)
		Return -1
	End
	
End