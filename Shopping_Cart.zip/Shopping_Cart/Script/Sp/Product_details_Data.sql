Create proc Product_details_Data
@activity_type Varchar(50),
@product Varchar(50),
@location varchar(max),
@User_id varchar(50)
as
begin

if(@activity_type='Add')
begin
	insert into Product_Details values(@product,@location,@User_id)

	select Count(*) as Product_Count from Product_Details
	Select Pk_id,Product,Location from product_details where user_id=@User_id
end
else
begin
	delete from Product_Details where Product=@product and User_id=@User_id

	select Count(*) as Product_Count from Product_Details
	Select Pk_id,Product,Location from product_details where user_id=@User_id
end

end