Create Proc Login_Details
@userid varchar(50),
@Password varchar(50)
as
begin

	if exists(Select 'X' from User_Details where User_Name=@userid)
	Begin
		if exists(Select 'X' from User_Details where Password=@Password)
		Begin
			Select * from User_Details where USER_NAME=@userid
		End
		Else
		Begin
			Raiserror('Invalid Paasword..!!',16,1)
			Return -1
		End
	End
	Else
	Begin
		Raiserror('Invalid User Name..!!',16,1)
		Return -1
	End

end