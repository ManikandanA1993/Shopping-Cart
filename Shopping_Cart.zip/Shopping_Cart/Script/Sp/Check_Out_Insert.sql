Create Proc Check_Out_Insert
@User_id Varchar(50)
AS
Begin

	insert into Check_out_details (Product,Location,user_id,Created_Date) 
	select Product,Location,user_id,Getdate() from Product_Details where user_id=@User_id

	delete from product_details where user_id=@User_id

End