Create Proc Check_Out_Initialize
@User_id Varchar(50)
as
begin

	Select Pk_id,Product,Location from product_details where user_id=@User_id
end