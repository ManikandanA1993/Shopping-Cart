Create table User_Details
(
Pk_Id int identity(1,1) not null,
User_Name Varchar(250) not null,
Password Varchar(max) not null,
Address Varchar(max) not null,
Mobile_No Varchar(10) not null,
Created_By Varchar(50) not null,
Created_On Datetime Not null,
Modified_By Varchar(50) null,
Modified_On Datetime null
)

--INsert into User_Details (User_Name,Password,Address,Mobile_No,Created_By,Created_On) values('Admin','123','Pilliya koi st','1234567890','Admin',Getdate())
--select * from User_Details