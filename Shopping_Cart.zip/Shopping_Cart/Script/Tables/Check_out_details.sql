
Create Table Check_out_details
(
Pk_id int identity(1,1) not null,
Product Varchar(50) not null,
Location Varchar(max) not null,
User_id varchar(50) not null,
Created_Date datetime not null default getdate()
)