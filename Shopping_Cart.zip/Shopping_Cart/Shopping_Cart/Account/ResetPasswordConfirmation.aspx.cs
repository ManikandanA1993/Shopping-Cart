﻿using System.Web.UI;

namespace Shopping_Cart.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}