﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AMS
{
    public partial class Login_Page : System.Web.UI.Page
    {
        string connectionstring = ConfigurationManager.ConnectionStrings["CnnStr"].ToString();
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void btnLogin_OnClick(object sender, EventArgs e)
        {
            try
            {
                Session["userid"] = rtxt_username.Text.Trim();
                SqlConnection con = new SqlConnection(connectionstring);
                con.Open();
                SqlCommand cmd = new SqlCommand("Login_Details", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@userid", SqlDbType.VarChar).Value = rtxt_username.Text.Trim();
                cmd.Parameters.Add("@password", SqlDbType.VarChar).Value = rtxt_password.Text.Trim();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds != null)
                {
                    if (ds.Tables.Count > 0)
                    {
                        Response.Redirect("~/User_Registeration.aspx");
                    }
                }
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message.ToString();
            }
        }
    }
}