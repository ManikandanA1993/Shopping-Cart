﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Shopping_Cart
{
    public partial class User_Registeration : System.Web.UI.Page
    {
        string connectionstring = ConfigurationManager.ConnectionStrings["CnnStr"].ToString();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                btnNext.Visible = false;

            }
        }

        protected void btnSave_OnClick(object sender, EventArgs e)
        {
            try
            {
                string Error = "";

                if (txtUsername.Text == "")
                    Error = "Please Enter User Name." + "<br/>";
                if (txtpassword.Text == "")
                    Error = Error + "Please Enter Password." + "<br/>";
                if (txtaddress.Text == "")
                    Error = Error + "Please Enter Address." + "<br/>";
                if (txtmobile.Text == "")
                    Error = Error + "Please Enter Mobile No." + "<br/>";
                if (txtmobile.Text != "")
                {
                    if (txtmobile.Text.Length != 10)
                        Error = Error + "Invalid Mobile No." + "<br/>";
                }

                if (Error == "")
                {
                    SqlConnection con = new SqlConnection(connectionstring);
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Login_Details_Insert", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    Session["User_Reg_Id"] = txtUsername.Text.Trim();
                    cmd.Parameters.Add("@userid", SqlDbType.VarChar).Value = txtUsername.Text.Trim();
                    cmd.Parameters.Add("@password", SqlDbType.VarChar).Value = txtpassword.Text.Trim();
                    cmd.Parameters.Add("@address", SqlDbType.VarChar).Value = txtaddress.Text.Trim();
                    cmd.Parameters.Add("@mobilno", SqlDbType.VarChar).Value = txtmobile.Text.Trim();
                    cmd.Parameters.Add("@log_id", SqlDbType.VarChar).Value = Session["userid"].ToString();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    if (ds != null)
                    {
                        if (ds.Tables.Count > 0)
                        {
                            txtUsername.Enabled = false;
                            txtpassword.Enabled = false;
                            txtreenter.Enabled = false;
                            txtaddress.Enabled = false;
                            txtmobile.Enabled = false;
                            btnNext.Visible = true;
                            lblMessage.Text = "User Registeration Process Completed..!!";
                        }
                    }
                }
                else
                {
                    lblMessage.Text = Error;
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }
        }
        protected void btnNext_OnClick(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("~/Product_list.aspx");
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }
        }
    }
}