﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Shopping_Cart
{
    public partial class Product_list : System.Web.UI.Page
    {
        string connectionstring = ConfigurationManager.ConnectionStrings["CnnStr"].ToString();
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    btnremove1.Visible = false;
                    btnremove2.Visible = false;
                    btnremove3.Visible = false;
                    btnremove4.Visible = false;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void btnadd1_OnClick(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(connectionstring);
                con.Open();
                SqlCommand cmd = new SqlCommand("Product_details_Data", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@activity_type", SqlDbType.VarChar).Value = "Add";
                cmd.Parameters.Add("@product", SqlDbType.VarChar).Value = "Mobile";
                cmd.Parameters.Add("@location", SqlDbType.VarChar).Value = "~/images/mobile.jpg";
                cmd.Parameters.Add("@User_id", SqlDbType.VarChar).Value = Session["User_Reg_Id"].ToString();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds != null)
                {
                    lblcart.Text = ds.Tables[0].Rows[0][0].ToString();
                }
                btnremove1.Visible = true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void btnremove1_OnClick(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(connectionstring);
                con.Open();
                SqlCommand cmd = new SqlCommand("Product_details_Data", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@activity_type", SqlDbType.VarChar).Value = "Remove";
                cmd.Parameters.Add("@product", SqlDbType.VarChar).Value = "Mobile";
                cmd.Parameters.Add("@location", SqlDbType.VarChar).Value = "~/images/mobile.jpg";
                cmd.Parameters.Add("@User_id", SqlDbType.VarChar).Value = Session["User_Reg_Id"].ToString();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds != null)
                {
                    lblcart.Text = ds.Tables[0].Rows[0][0].ToString();
                    btnremove1.Visible = false;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void btnadd2_OnClick(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(connectionstring);
                con.Open();
                SqlCommand cmd = new SqlCommand("Product_details_Data", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@activity_type", SqlDbType.VarChar).Value = "Add";
                cmd.Parameters.Add("@product", SqlDbType.VarChar).Value = "Tv";
                cmd.Parameters.Add("@location", SqlDbType.VarChar).Value = "~/images/Tv.jpg";
                cmd.Parameters.Add("@User_id", SqlDbType.VarChar).Value = Session["User_Reg_Id"].ToString();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds != null)
                {
                    lblcart.Text = ds.Tables[0].Rows[0][0].ToString();
                }
                btnremove2.Visible = true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void btnremove2_OnClick(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(connectionstring);
                con.Open();
                SqlCommand cmd = new SqlCommand("Product_details_Data", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@activity_type", SqlDbType.VarChar).Value = "Remove";
                cmd.Parameters.Add("@product", SqlDbType.VarChar).Value = "Tv";
                cmd.Parameters.Add("@location", SqlDbType.VarChar).Value = "~/images/Tv.jpg";
                cmd.Parameters.Add("@User_id", SqlDbType.VarChar).Value = Session["User_Reg_Id"].ToString();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds != null)
                {
                    lblcart.Text = ds.Tables[0].Rows[0][0].ToString();
                    btnremove2.Visible = false;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void btnadd3_OnClick(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(connectionstring);
                con.Open();
                SqlCommand cmd = new SqlCommand("Product_details_Data", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@activity_type", SqlDbType.VarChar).Value = "Add";
                cmd.Parameters.Add("@product", SqlDbType.VarChar).Value = "Bag";
                cmd.Parameters.Add("@location", SqlDbType.VarChar).Value = "~/images/Bag.jpg";
                cmd.Parameters.Add("@User_id", SqlDbType.VarChar).Value = Session["User_Reg_Id"].ToString();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds != null)
                {
                    lblcart.Text = ds.Tables[0].Rows[0][0].ToString();
                }
                btnremove3.Visible = true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void btnremove3_OnClick(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(connectionstring);
                con.Open();
                SqlCommand cmd = new SqlCommand("Product_details_Data", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@activity_type", SqlDbType.VarChar).Value = "Remove";
                cmd.Parameters.Add("@product", SqlDbType.VarChar).Value = "Bag";
                cmd.Parameters.Add("@location", SqlDbType.VarChar).Value = "~/images/Bag.jpg";
                cmd.Parameters.Add("@User_id", SqlDbType.VarChar).Value = Session["User_Reg_Id"].ToString();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds != null)
                {
                    lblcart.Text = ds.Tables[0].Rows[0][0].ToString();
                    btnremove3.Visible = false;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void btnadd4_OnClick(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(connectionstring);
                con.Open();
                SqlCommand cmd = new SqlCommand("Product_details_Data", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@activity_type", SqlDbType.VarChar).Value = "Add";
                cmd.Parameters.Add("@product", SqlDbType.VarChar).Value = "Laptop";
                cmd.Parameters.Add("@location", SqlDbType.VarChar).Value = "~/images/Laptop.jpg";
                cmd.Parameters.Add("@User_id", SqlDbType.VarChar).Value = Session["User_Reg_Id"].ToString();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds != null)
                {
                    lblcart.Text = ds.Tables[0].Rows[0][0].ToString();
                }
                btnremove4.Visible = true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void btnremove4_OnClick(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(connectionstring);
                con.Open();
                SqlCommand cmd = new SqlCommand("Product_details_Data", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@activity_type", SqlDbType.VarChar).Value = "Remove";
                cmd.Parameters.Add("@product", SqlDbType.VarChar).Value = "Laptop";
                cmd.Parameters.Add("@location", SqlDbType.VarChar).Value = "~/images/Laptop.jpg";
                cmd.Parameters.Add("@User_id", SqlDbType.VarChar).Value = Session["User_Reg_Id"].ToString();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds != null)
                {
                    lblcart.Text = ds.Tables[0].Rows[0][0].ToString();
                    btnremove4.Visible = false;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void btnSave_OnClick(object sender, EventArgs e)
        {
            Response.Redirect("~/Check_out_Details.aspx");
        }
    }
}