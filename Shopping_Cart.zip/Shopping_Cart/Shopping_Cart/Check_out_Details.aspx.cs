﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Shopping_Cart
{
    public partial class Check_out_Details : System.Web.UI.Page
    {
        string connectionstring = ConfigurationManager.ConnectionStrings["CnnStr"].ToString();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                Initialize();
                btnSave.Enabled = true;
                btnBack.Visible = false;
            }
        }
        public void Initialize()
        {
            try
            {
                SqlConnection con = new SqlConnection(connectionstring);
                con.Open();
                SqlCommand cmd = new SqlCommand("Check_Out_Initialize", con);
                cmd.Parameters.Add("@User_id", SqlDbType.VarChar).Value = Session["User_Reg_Id"].ToString();
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds != null)
                {
                    rgGridDetails.DataSource = ds.Tables[0];
                    rgGridDetails.DataBind();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        protected void rgGridDetails_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                GridViewRow rows = rgGridDetails.SelectedRow;
                HiddenField sno = (HiddenField)rows.FindControl("gvhdsno");
                Label pro = (Label)rows.FindControl("glblproduct");
                Image img = (Image)rows.FindControl("glbllocation");


                SqlConnection con = new SqlConnection(connectionstring);
                con.Open();
                SqlCommand cmd = new SqlCommand("Product_details_Data", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@activity_type", SqlDbType.VarChar).Value = "Remove";
                cmd.Parameters.Add("@product", SqlDbType.VarChar).Value = pro.Text;
                cmd.Parameters.Add("@location", SqlDbType.VarChar).Value = img.ImageUrl.ToString();
                cmd.Parameters.Add("@User_id", SqlDbType.VarChar).Value = Session["User_Reg_Id"].ToString();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds != null)
                {
                    rgGridDetails.DataSource = ds.Tables[1];
                    rgGridDetails.DataBind();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        protected void btnSave_OnClick(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(connectionstring);
                con.Open();
                SqlCommand cmd = new SqlCommand("Check_Out_Insert", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@User_id", SqlDbType.VarChar).Value = Session["User_Reg_Id"].ToString();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds != null)
                {
                    btnSave.Enabled = false;
                    lblMessage.Text = "Your Product Place in order Successfully..!!";
                    btnBack.Visible = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        protected void btnBack_OnClick(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("~/Product_list.aspx");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}